<?php
include "./server/conexion.php";

if ($id = $_GET['id'])


?>