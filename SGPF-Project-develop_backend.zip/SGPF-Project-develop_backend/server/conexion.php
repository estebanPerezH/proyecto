<?php
$host = 'localhost';
$db = 'sgpf';
$username = 'root';
$password = '';

$conn = mysqli_connect($host, $username, $password, $db);

?>