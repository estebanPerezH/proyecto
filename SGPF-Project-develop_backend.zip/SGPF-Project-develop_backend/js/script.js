document.getElementById("menu").addEventListener("click",function(){
  
    document.getElementById("navega").classList.toggle("mostrar");
  });